//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
// File: compile.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 17-Feb-2022 09:37:07
//

#ifndef COMPILE_H
#define COMPILE_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void compile(double a, coder::array<double, 2U> &output);

#endif
//
// File trailer for compile.h
//
// [EOF]
//
