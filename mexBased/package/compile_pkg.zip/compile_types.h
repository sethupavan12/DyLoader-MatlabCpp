//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
// File: compile_types.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 17-Feb-2022 09:37:07
//

#ifndef COMPILE_TYPES_H
#define COMPILE_TYPES_H

// Include Files
#include "rtwtypes.h"

#endif
//
// File trailer for compile_types.h
//
// [EOF]
//
