//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
// File: compile_terminate.cpp
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 17-Feb-2022 09:37:07
//

// Include Files
#include "compile_terminate.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void compile_terminate()
{
  // (no terminate code required)
}

//
// File trailer for compile_terminate.cpp
//
// [EOF]
//
