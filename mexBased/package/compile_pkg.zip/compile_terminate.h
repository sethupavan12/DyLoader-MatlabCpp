//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
// File: compile_terminate.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 17-Feb-2022 09:37:07
//

#ifndef COMPILE_TERMINATE_H
#define COMPILE_TERMINATE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void compile_terminate();

#endif
//
// File trailer for compile_terminate.h
//
// [EOF]
//
