//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
// File: compile_initialize.cpp
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 25-Feb-2022 15:49:42
//

// Include Files
#include "compile_initialize.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void compile_initialize()
{
}

//
// File trailer for compile_initialize.cpp
//
// [EOF]
//
