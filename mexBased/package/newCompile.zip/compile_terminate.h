//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
// File: compile_terminate.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 25-Feb-2022 15:49:42
//

#ifndef COMPILE_TERMINATE_H
#define COMPILE_TERMINATE_H

// Include Files
#include "compile_spec.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
COMPILE_DLL_EXPORT extern void compile_terminate();

#endif
//
// File trailer for compile_terminate.h
//
// [EOF]
//
