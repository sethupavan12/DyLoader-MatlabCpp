//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
// File: compile_initialize.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 25-Feb-2022 15:49:42
//

#ifndef COMPILE_INITIALIZE_H
#define COMPILE_INITIALIZE_H

// Include Files
#include "compile_spec.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
COMPILE_DLL_EXPORT extern void compile_initialize();

#endif
//
// File trailer for compile_initialize.h
//
// [EOF]
//
