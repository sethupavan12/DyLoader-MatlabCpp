//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
// File: compile.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 25-Feb-2022 15:49:42
//

#ifndef COMPILE_H
#define COMPILE_H

// Include Files
#include "compile_spec.h"
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
COMPILE_DLL_EXPORT extern void compile(double a,
                                       coder::array<double, 2U> &output);

#endif
//
// File trailer for compile.h
//
// [EOF]
//
